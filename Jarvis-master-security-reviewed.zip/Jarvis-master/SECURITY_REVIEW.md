# JARVIS personal-build security review

Changes in this source package:
- Sentry movement detection no longer silently activates the front camera. It emits a movement event only.
- SMS inbox reading remains supported through READ_SMS (and can fall back to notification-listener messages).
- SEND_SMS and RECEIVE_SMS manifest permissions were removed because the inspected source did not implement direct SMS sending or an SMS broadcast receiver.
- SMS and contacts are no longer included in the onboarding batch permission request; they remain individually requestable when their feature is used.

Important limitations identified during review:
- The current code reads the SMS inbox, but no direct SmsManager send implementation was found. Sending should be implemented using an explicit user-confirmed SMS compose flow, or a separately reviewed direct-send implementation.
- Contact search/read is implemented; contact creation/update was not found in the inspected service.
- android:usesCleartextTraffic="true" remains in the manifest because the app contains configurable local Home Assistant HTTP support and an HTTP ISS endpoint. This should be replaced with a scoped network-security configuration before a hardened release.
- Accessibility and notification-listener access are highly privileged Android settings. Enable them only after reviewing the on-screen disclosures.
- This is a source-level safety patch, not a verified compiled APK. Build and device-test it before installation.

Do not disable Google Play Protect as a workaround. A private sideloaded app can still be scanned or blocked.
